<template>
    <div class="position-static">
    <!-- <div class="position-absolute top-50 start-100"> -->
  <div class="register">
      <div class="card align-middle">
        <h3>Register page</h3>
    <form @submit.prevent="registerUser">
      <div>
        <label>Email:</label>
        <input type="email" v-model="email" required />
      </div><br>
      <div>
        <label>Password:</label>
        <input type="password" v-model="password" required />
      </div><br>
      <div>
        <label>Username:</label>
        <input type="text" v-model="userName" required />
      </div><br>
      <button type="submit">Register</button>
      <button type="button" @click="$router.push('/login')">Sign In</button>
    </form>
    <p v-if="message">{{ message }}</p>
  </div>
</div>
</div>
</template>

<script>
 import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';


export default {
  data() {
    return {
      email: '',
      password: '',
      userName: '',
      message: ''
    };
  },
  methods: {
    registerUser() {
      axios.post(`${API_BASE_URL}/register`, {
        email: this.email,
        password: this.password,
        userName: this.userName
      })
        .then(response => {
          this.message = response.data.message;
          // Clear the form fields after successful login
          this.email = '';
          this.password = '';
          this.userName = '';
            // Perform any other actions after successful registration
          this.$router.push('/login'); // Redirect to '/login'
        })
        .catch(error => {
          if (error.response && error.response.data.message) {
            this.message = error.response.data.message;
          } else {
            this.message = error.message;
          }
        });
    },
  },
};
</script>