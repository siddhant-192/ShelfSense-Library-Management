<template>
  <div class="search">
    <nav>
      <div class="left">
        Hello {{ userName }}
      </div>
      <div class="center">
        ShelfSense
      </div>
      <div class="right">
        <router-link to="/home" style="color: white;">Home</router-link> |
        <router-link to="/search" style="color: white;">Search</router-link> |
        <router-link to="/profile" style="color: white;">Profile</router-link> |
        <router-link @click="logout" to="#" style="color: white;">Logout</router-link>
      </div>
    </nav>

    <div class="search-bar">
      <input type="text" v-model="searchQuery" placeholder="Search for books or sections..." />
      <button @click="searchBooksAndSections">Search</button>
    </div>

    <div class="search-results" v-if="bookSearchResults.length > 0 || sectionSearchResults.length > 0">
      <!-- Book Search Results -->
      <div v-if="bookSearchResults.length > 0">
        <h2>Book Search Results</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Authors</th>
              <th>Section ID</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="book in bookSearchResults" :key="book.id">
              <td>{{ book.name }}</td>
              <td>{{ book.authors }}</td>
              <td>{{ book.section_id }}</td>
              <td>
                <router-link
                  :to="{ name: 'book', params: { id: book.id }, query: { userId: userId } }"
                  :class="{
                    'issue-button': !book.issue_status,
                    'return-button': book.issue_status && userId === usernameIssued
                  }"
                >
                  {{ book.issue_status && userId === usernameIssued ? 'Return' : 'Open' }}
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Section Search Results -->
      <div v-if="sectionSearchResults.length > 0">
        <h2>Section Search Results</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>ID</th>
              <th>Description</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="section in sectionSearchResults" :key="section.id">
              <td>{{ section.name }}</td>
              <td>{{ section.id }}</td>
              <td>{{ section.description }}</td>
              <td>
                <router-link :to="{ name: 'section', params: { id: section.id } }">
                  Open
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Author Search Results -->
      <div v-if="authorSearchResults.length > 0">
        <h2>Authors Search Results</h2>
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Authors</th>
              <th>Section ID</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="book in authorSearchResults" :key="book.id">
              <td>{{ book.name }}</td>
              <td>{{ book.authors }}</td>
              <td>{{ book.section_id }}</td>
              <td>
                <router-link
                  :to="{ name: 'book', params: { id: book.id }, query: { userId: userId } }"
                  class="issue-button"
                >
                  Open
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export default {
  data() {
    return {
      userName: localStorage.getItem('userName') || 'User',
      userId: localStorage.getItem('userId'),
      searchQuery: '',
      bookSearchResults: [],
      sectionSearchResults: [],
      authorSearchResults: [],
      usernameIssued: null,
    };
  },
  methods: {
    async searchBooksAndSections() {
  try {
    const authToken = localStorage.getItem('authToken');

    // Search for books
    const bookResponse = await axios.get(`${API_BASE_URL}/book_search/${this.searchQuery}`, {
      params: { query: this.searchQuery },
      headers: {
        "Authorization": `${authToken}`,
      },
    });
    this.bookSearchResults = bookResponse.data;

    // Search for sections
    const sectionResponse = await axios.post(
      `${API_BASE_URL}/section_search`,
      { section_name: this.searchQuery },
      {
        headers: {
          'Authorization': `${authToken}`,
        },
      }
    );
    this.sectionSearchResults = sectionResponse.data;

    // Search for books by author
    const authorResponse = await axios.get(`${API_BASE_URL}/search_book_by_author`, {
      params: { author_name: this.searchQuery },  // Send as query parameter
      headers: {
        'Authorization': `${authToken}`,
      },
    });
    this.authorSearchResults = authorResponse.data;
  } catch (error) {
    console.error('Error searching books and sections:', error);
  }
},
    logout() {
      localStorage.clear();
      this.$router.push('/login');
    },
  },
};
</script>

<style scoped>
nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px;
}

.search-bar {
  margin-top: 20px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

th {
  background-color: #f2f2f2;
}

.issue-button {
  color: green;
  text-decoration: none;
}

.return-button {
  color: red;
  text-decoration: none;
}

button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}
</style>
