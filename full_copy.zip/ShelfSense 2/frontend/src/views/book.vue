<template>
  <div class="book">
    <nav>
      <div class="left">
        Hello {{ userName }}
      </div>
      <div class="center">
        ShelfSense
      </div>
      <div class="right">
        <router-link to="/home" style="color: white;">Home</router-link> |
        <router-link @click.prevent="triggerSearch" to="#" style="color: white;">Search</router-link> |
        <router-link @click.prevent="getUserDetails" to="#" style="color: white;">Profile</router-link> |
        <router-link @click.prevent="logout" to="#" style="color: white;">Logout</router-link>
      </div>
    </nav>

    <div class="content" v-if="book">
      <div class="book-details">
        <h2>{{ book.name }}</h2>
        <p>Book ID: {{ book.id }}</p>
        <p>Authors: {{ book.authors }}</p>
        <p>Section ID: {{ book.section_id }}</p>
      </div>

      <div class="book-status">
        <div v-if="bookStatus === 0">
          <button @click="issueBook">Issue Book</button>
        </div>
        <div v-else-if="bookStatus === 1">
          <button @click="returnBook">Return Book</button>
          <div class="content-section">
            <h3>Content</h3>
            <p>{{ book.content }}</p>
          </div>
        </div>
        <div v-else-if="bookStatus === 2">
          <p>This book is currently issued by {{ usernameIssued }}.</p>
        </div>
      </div>

      <div class="feedback-section">
        <h3>Feedback</h3>
        <textarea v-model="newFeedback" placeholder="Enter your feedback"></textarea>
        <button @click="submitFeedback">Submit Feedback</button>

        <h3>Comments</h3>
        <div v-for="comment in comments" :key="comment.id" class="comment-item">
          <p><strong>{{ comment.username }}</strong>: {{ comment.feedback }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export default {
  data() {
    return {
      userName: localStorage.getItem('userName') || 'User',
      userId: localStorage.getItem('userId'),
      bookId: this.$route.params.id,
      book: null,
      bookStatus: null,
      usernameIssued: null,
      newFeedback: '',
      comments: [],
    };
  },
  methods: {
    async getUserDetails() {
      try {
        const authToken = localStorage.getItem('authToken');
        const userId = localStorage.getItem('userId');
        const response = await axios.get(`${API_BASE_URL}/get_user/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        const userData = response.data;
        localStorage.setItem('userData', JSON.stringify(userData));
        this.$router.push('/profile');
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    },
    triggerSearch() {
      const authToken = localStorage.getItem('authToken');
      const userId = localStorage.getItem('userId');
      const userRole = localStorage.getItem('userRole');
      localStorage.setItem('searchAuth', JSON.stringify({ authToken, userId, userRole }));
      this.$router.push('/search');
    },
    logout() {
      localStorage.clear();
      this.$router.push('/login');
    },
    async issueBook() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.post(`${API_BASE_URL}/issue_book`, {
          user_id: this.userId,
          book_id: this.book.id,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        if (response.data.message === 'User has already issued 5 books. No more can be alloted at once.') {
          alert(response.data.message);
          return;
        }
        console.log(response.data);
        await this.getBookStatus();
      } catch (error) {
        console.error('Error issuing book:', error);
      }
    },
    async returnBook() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.post(`${API_BASE_URL}/return_book`, {
          book_id: this.book.id,
          user_id: this.userId,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        console.log(response.data);
        await this.getBookStatus();
      } catch (error) {
        console.error('Error returning book:', error);
      }
    },
    async getBookStatus() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.post(`${API_BASE_URL}/book_issue_status`, {
          book_id: this.$route.params.id,
          user_id: this.userId,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.bookStatus = response.data.message;
        this.usernameIssued = response.data.username_issued;
        if (this.bookStatus === 1) {
          const bookResponse = await axios.get(`${API_BASE_URL}/books/${this.$route.params.id}`, {
            headers: {
              "Authorization": `${authToken}`,
            },
          });
          this.book = bookResponse.data;
          await this.getBookComments();
        }
      } catch (error) {
        console.error('Error getting book status:', error);
      }
    },
    async submitFeedback() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.post(`${API_BASE_URL}/feedback`, {
          user_id: parseInt(this.userId),
          book_id: this.book.id,
          feedback_msg: this.newFeedback,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        console.log(response.data);
        alert('Feedback submitted successfully!');
        this.newFeedback = '';
        await this.getBookComments();
      } catch (error) {
        console.error('Error submitting feedback:', error);
      }
    },
    async getBookComments() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.post(`${API_BASE_URL}/feedback_by_bookid`, {
          book_id: this.book.id,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.comments = response.data;
      } catch (error) {
        console.error('Error fetching book comments:', error);
      }
    },
  },
  async mounted() {
    const authToken = localStorage.getItem('authToken');
    if (!authToken) {
      this.$router.push('/login');
      return;
    }

    try {
      const bookResponse = await axios.get(`${API_BASE_URL}/books/${this.$route.params.id}`, {
        headers: {
          "Authorization": `${authToken}`,
        },
      });
      this.book = bookResponse.data;
      await this.getBookComments();

      await this.getBookStatus();
    } catch (error) {
      console.error('Error fetching book data:', error);
    }
  },
};
</script>

<style scoped>
nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px;
}

.content {
  padding: 20px;
}

.book-details {
  margin-bottom: 40px;
}

.book-status {
  margin-bottom: 40px;
}

.content-section {
  margin-top: 20px;
}

.feedback-section {
  margin-top: 40px;
}

.comment-item {
  margin-top: 10px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}
</style>