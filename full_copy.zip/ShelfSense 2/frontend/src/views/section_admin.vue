<template>
    <div class="section_admin">
      <nav>
        <div class="left">
          Welcome Admin
        </div>
        <div class="center">
          ShelfSense
        </div>
        <div class="right">
          <router-link to="/dashboard" style="color: white;">Home</router-link> |
          <router-link @click.prevent="logout" to="#" style="color: white;">Logout</router-link>
        </div>
      </nav>
  
      <div class="section">
        <h1>{{ section.name }}</h1>
  
        <p>Section ID: {{ section.id }}</p>
  
        <p>{{ section.description }}</p>
  
        <table class="books-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Authors</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="book in books" :key="book.id">
              <td>{{ book.id }}</td>
              <td>{{ book.name }}</td>
              <td>{{ book.authors }}</td>
              <td>
                <button @click="openBook(book.id)">Open</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  const API_BASE_URL = 'http://localhost:5000/api';
  
  export default {
    data() {
      return {
        section: {},
        books: [],
      };
    },
    methods: {
      logout() {
        localStorage.clear();
        this.$router.push('/login');
      },
      async openBook(bookId) {
        this.$router.push(`/book_admin/${bookId}`);
      },
    },
    async mounted() {
      const authToken = localStorage.getItem('authToken');
      if (!authToken) {
        this.$router.push('/login');
        return;
      }
  
      try {
        // Fetch section details
        const sectionId = this.$route.params.id;
        const sectionResponse = await axios.get(`${API_BASE_URL}/section/${sectionId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.section = sectionResponse.data;
  
        // Fetch books in the section
        const booksResponse = await axios.get(`${API_BASE_URL}/books`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.books = booksResponse.data.filter((book) => book.section_id === this.section.id);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    },
  };
  </script>
  
  <style scoped>
  nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px;
}
  
  .section {
    padding: 20px;
  }
  
  table {
    width: 100%;
    border-collapse: collapse;
  }
  
  th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }
  
  button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}
  </style>