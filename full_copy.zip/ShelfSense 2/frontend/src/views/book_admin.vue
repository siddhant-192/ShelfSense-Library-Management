<template>
    <div class="book_admin">
        <nav>
            <div class="left">
                Welcome Admin
            </div>
            <div class="center">
                ShelfSense
            </div>
            <div class="right">
                <router-link to="/dashboard" style="color: white;">Home</router-link> |
                <router-link @click.prevent="logout" to="#" style="color: white;">Logout</router-link>
            </div>
        </nav>

        <div class="content" v-if="book">
            <div class="book-details">
                <h2>{{ book.name }}</h2>
                <p>Book ID: {{ book.id }}</p>
                <p>Authors: {{ book.authors }}</p>
                <p>Section ID: {{ book.section_id }}</p>
            </div>

            <div class="content-section">
                <h3>Content</h3>
                <p>{{ book.content }}</p>
            </div>

            <div class="feedback-section">
                <h3>Comments</h3>
                <div v-if="comments.length > 0">
                    <div v-for="comment in comments" :key="comment.id" class="comment-item">
                        <p><strong>{{ comment.username }}</strong>: {{ comment.feedback }}</p>
                    </div>
                </div>
                <div v-else>
                    <p>No comments yet.</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export default {
    data() {
        return {
            book: null,
            comments: [],
        };
    },
    methods: {
        logout() {
            localStorage.clear();
            this.$router.push('/login');
        },
        async getBookComments() {
            try {
                const authToken = localStorage.getItem('authToken');
                const response = await axios.post(`${API_BASE_URL}/feedback_by_bookid`, {
                    book_id: this.book.id,
                }, {
                    headers: {
                        "Authorization": `${authToken}`,
                    },
                });
                this.comments = response.data;
            } catch (error) {
                console.error('Error fetching book comments:', error);
            }
        },
    },
    async mounted() {
        const authToken = localStorage.getItem('authToken');
        if (!authToken) {
            this.$router.push('/login');
            return;
        }

        try {
            const bookResponse = await axios.get(`${API_BASE_URL}/books/${this.$route.params.id}`, {
                headers: {
                    "Authorization": `${authToken}`,
                },
            });
            this.book = bookResponse.data;
            await this.getBookComments();
        } catch (error) {
            console.error('Error fetching book data:', error);
        }
    },
};
</script>

<style scoped>
nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333333;
  color: #fff;
  padding: 10px;
}

.content {
    padding: 20px;
}

.book-details {
    margin-bottom: 40px;
}

.content-section {
    margin-top: 20px;
}

.feedback-section {
    margin-top: 40px;
}

.comment-item {
    margin-top: 10px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}
</style>