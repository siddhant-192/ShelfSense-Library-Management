<template>
  <div class="dashboard">
    <nav>
      <div class="left">
        Welcome Admin
      </div>
      <div class="center">
        ShelfSense
      </div>
      <div class="right">
        <button to="/dashboard" style="color: white;">Home</button>
        <button @click="logout" style="color: white;">Logout</button>
      </div>
    </nav>

    <div class="content">
      <!-- Books section -->
      <div class="books-section">
        <div class="header">
          <h2>Books</h2>
          <button @click="openAddBookModal">Add Book</button>
        </div>
        <table class="books-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Authors</th>
              <th>Section</th>
              <th>Issue Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="book in books" :key="book.id">
              <td>{{ book.id }}</td>
              <td>{{ book.name }}</td>
              <td>{{ book.authors }}</td>
              <td>{{ getSectionName(book.section_id) }}</td>
              <td>{{  book.issue_status }}</td>
              <td>
                <button @click="openBook(book.id)">Open</button>
                <button @click="openUpdateBookModal(book)">Update</button>
                <button @click="deleteBook(book.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Sections section -->
      <div class="sections-section" style="margin-top: 80px;">
        <div class="header">
          <h2>Sections</h2>
          <button @click="openAddSectionModal">Add Section</button>
        </div>
        <table class="sections-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Description</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="section in sections" :key="section.id">
              <td>{{ section.id }}</td>
              <td>{{ section.name }}</td>
              <td>{{ section.description }}</td>
              <td>
                <button @click="openSection(section.id)">Open</button>
                <button @click="openUpdateSectionModal(section)">Update</button>
                <button @click="deleteSection(section.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Users section -->
      <div class="users-section" style="margin-top: 80px;">
        <div class="header">
          <h2>Users</h2>
          <button @click="openAddUserModal">Add User</button>
        </div>
        <table class="users-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Last Login Time</th>
              <th>Login Count</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="user in users" :key="user.id">
              <td>{{ user.id }}</td>
              <td>{{ user.username }}</td>
              <td>{{ user.email }}</td>
              <td>{{ user.last_login_at }}</td>
              <td>{{ user.login_count }}</td>
              <td>
                <button @click="openUserProfile(user.id)">Open</button>
                <button @click="deleteUser(user.id)">Delete</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Issued Books section -->
      <div class="issued-books-section" style="margin-top: 80px;">
        <div class="header">
          <h2>Issued Books</h2>
          <button @click="openIssueBookModal">Issue Book</button>
        </div>
        <table class="issued-books-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Book Name</th>
              <th>Issue Date</th>
              <th>Return</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="issue in issuedBooks" :key="issue.id">
              <td>{{ issue.id }}</td>
              <td>{{ getUser(issue.user_id).username }}</td>
              <td>{{ getBook(issue.book_id).name }}</td>
              <td>{{ issue.date_issued }}</td>
              <td>
                <button @click="returnBook(issue.book_id, issue.user_id)">Unissue</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modals -->
    <div class="modal" v-if="showAddBookModal">
      <div class="modal-content">
        <span class="close" @click="closeAddBookModal">&times;</span>
        <h2>Add Book</h2>
        <form @submit.prevent="addBook">
          <label>
            Name:
            <input type="text" v-model="newBook.name" required>
          </label><br>
          <label>
            Authors:
            <input type="text" v-model="newBook.authors" required>
          </label><br>
          <label>
            Section:
            <select v-model="newBook.section_id" required>
              <option v-for="section in sections" :value="section.id">{{ section.name }}</option>
            </select><br>
          </label>
          <label>
            Content:
            <textarea v-model="newBook.content" required></textarea>
          </label><br>
          <button type="submit">Add</button>
        </form>
      </div>
    </div>

    <div class="modal" v-if="showAddSectionModal">
      <div class="modal-content">
        <span class="close" @click="closeAddSectionModal">&times;</span>
        <h2>Add Section</h2>
        <form @submit.prevent="addSection">
          <label>
            Name:
            <input type="text" v-model="newSection.name" required>
          </label><br>
          <label>
            Description:
            <textarea v-model="newSection.description" required></textarea>
          </label><br>
          <button type="submit">Add</button>
        </form>
      </div>
    </div>

    <div class="modal" v-if="showAddUserModal">
      <div class="modal-content">
        <span class="close" @click="closeAddUserModal">&times;</span>
        <h2>Add User</h2>
        <form @submit.prevent="addUser">
          <label>
            Username:
            <input type="text" v-model="newUser.userName" required>
          </label><br>
          <label>
            Email:
            <input type="email" v-model="newUser.email" required>
          </label><br>
          <label>
            Password:
            <input type="password" v-model="newUser.password" required>
          </label><br>
          <button type="submit">Add</button>
        </form>
      </div>
    </div>

    <div class="modal" v-if="showIssueBookModal">
      <div class="modal-content">
        <span class="close" @click="closeIssueBookModal">&times;</span>
        <h2>Issue Book</h2>
        <form @submit.prevent="issueBook">
          <label>
            User ID:
            <input type="text" v-model="issueBookData.user_id" required>
          </label><br>
          <label>
            Book ID:
            <input type="text" v-model="issueBookData.book_id" required>
          </label><br>
          <button type="submit">Issue</button>
        </form>
      </div>
    </div>

    <!-- Update Book Modal -->
    <div class="modal" v-if="showUpdateBookModal">
  <div class="modal-content">
    <span class="close" @click="closeUpdateBookModal">&times;</span>
    <h2>Update Book</h2>
    <form @submit.prevent="updateBook">
      <label>
        Name:
        <input type="text" v-model="updatedBook.name" required>
      </label><br>
      <label>
        Authors:
        <input type="text" v-model="updatedBook.authors" required>
      </label><br>
      <label>
        Section:
        <select v-model="updatedBook.section_id" required>
          <option v-for="section in sections" :value="section.id">{{ section.name }}</option>
        </select>
      </label><br>
      <label>
        Content:
        <textarea v-model="updatedBook.content" required></textarea>
      </label><br>
      <button type="submit">Update</button>
    </form>
  </div>
</div>

    <!-- Update Section Modal -->
    <div class="modal" v-if="showUpdateSectionModal">
      <div class="modal-content">
        <span class="close" @click="closeUpdateSectionModal">&times;</span>
        <h2>Update Section</h2>
        <form @submit.prevent="updateSection">
          <label>
            Name:
            <input type="text" v-model="updatedSection.name" required>
          </label><br>
          <label>
            Description:
            <textarea v-model="updatedSection.description" required></textarea>
          </label><br>
          <button type="submit">Update</button>
        </form>
      </div>
    </div>

    <!-- Success Alert -->
    <div class="alert" v-if="showSuccessAlert">
      <p>{{ successMessage }}</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export default {
  data() {
    return {
      books: [],
      sections: [],
      users: [],
      issuedBooks: [],
      showAddBookModal: false,
      showAddSectionModal: false,
      showAddUserModal: false,
      showIssueBookModal: false,
      newBook: {
        name: '',
        authors: '',
        section_id: null,
        content: '',
      },
      newSection: {
        name: '',
        description: '',
      },
      newUser: {
        userName: '',
        email: '',
        password: '',
      },
      issueBookData: {
        user_id: '',
        book_id: '',
      },
      showUpdateBookModal: false,
      showUpdateSectionModal: false,
      updatedBook: null,
      updatedSection: null,
      successMessage: '',
      showSuccessAlert: false,
    };
  },
  methods: {
    async logout() {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.get(`${API_BASE_URL}/logout`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        localStorage.clear();
        this.$router.push('/login');
      } catch (error) {
        console.error('Error logging out:', error);
      }
    },
    async openBook(bookId) {
      this.$router.push(`/book_admin/${bookId}`);
    },
    async openSection(sectionId) {
      this.$router.push(`/section_admin/${sectionId}`);
    },
    async returnBook(bookId, userId) {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.post(`${API_BASE_URL}/return_book`, {
          book_id: bookId,
          user_id: userId,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        await this.getIssues();
        await this.getBooks(); // Fetch the updated books
      } catch (error) {
        console.error('Error returning book:', error);
      }
    },
    getSectionName(sectionId) {
      const section = this.sections.find((section) => section.id === sectionId);
      return section ? section.name : '';
    },
    getBook(bookId) {
      return this.books.find((book) => book.id === bookId);
    },
    getUser(userId) {
      return this.users.find((user) => user.id === userId);
    },
    async getBooks() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.get(`${API_BASE_URL}/books`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.books = response.data;
      } catch (error) {
        console.error('Error fetching books:', error);
      }
    },
    async getSections() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.get(`${API_BASE_URL}/section`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.sections = response.data;
      } catch (error) {
        console.error('Error fetching sections:', error);
      }
    },
    async getUsers() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.get(`${API_BASE_URL}/get_all_users`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.users = response.data;
      } catch (error) {
        console.error('Error fetching users:', error);
      }
    },
    async getIssues() {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.get(`${API_BASE_URL}/all_issued_books`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.issuedBooks = response.data.filter(issue => issue.return_date === null);
      } catch (error) {
        console.error('Error fetching issued books:', error);
      }
    },
    openAddBookModal() {
      this.showAddBookModal = true;
    },
    closeAddBookModal() {
      this.showAddBookModal = false;
    },
    async addBook() {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.post(`${API_BASE_URL}/books`, this.newBook, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.closeAddBookModal();
        await this.getBooks();
      } catch (error) {
        console.error('Error adding book:', error);
      }
    },
    openAddSectionModal() {
      this.showAddSectionModal = true;
    },
    closeAddSectionModal() {
      this.showAddSectionModal = false;
    },
    async addSection() {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.post(`${API_BASE_URL}/section`, this.newSection, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.closeAddSectionModal();
        await this.getSections();
      } catch (error) {
        console.error('Error adding section:', error);
      }
    },
    openAddUserModal() {
      this.showAddUserModal = true;
    },
    closeAddUserModal() {
      this.showAddUserModal = false;
    },
    async addUser() {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.post(`${API_BASE_URL}/register`, this.newUser, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.closeAddUserModal();
        await this.getUsers();
      } catch (error) {
        console.error('Error adding user:', error);
      }
    },
    openIssueBookModal() {
      this.showIssueBookModal = true;
    },
    closeIssueBookModal() {
      this.showIssueBookModal = false;
    },
    async issueBook() {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.post(`${API_BASE_URL}/issue_book`, this.issueBookData, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.closeIssueBookModal();
        await this.getIssues();
        await this.getBooks(); // Fetch the updated books
      } catch (error) {
        console.error('Error issuing book:', error);
      }
    },
    async deleteBook(bookId) {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.delete(`${API_BASE_URL}/books/${bookId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        await this.getBooks();
      } catch (error) {
        console.error('Error deleting book:', error);
      }
    },
    async deleteSection(sectionId) {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.delete(`${API_BASE_URL}/section/${sectionId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        await this.getSections();
        await this.getBooks();
      } catch (error) {
        console.error('Error deleting section:', error);
      }
    },
    async deleteUser(userId) {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.delete(`${API_BASE_URL}/delete_user/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        await this.getUsers();
      } catch (error) {
        console.error('Error deleting user:', error);
      }
    },
    async openUpdateBookModal(book) {
      this.updatedBook = { ...book };
      await this.getSections(); // Fetch the current sections
      this.showUpdateBookModal = true;
    },

    closeUpdateBookModal() {
      this.showUpdateBookModal = false;
    },

    async updateBook() {
  try {
    const authToken = localStorage.getItem('authToken');
    await axios.put(`${API_BASE_URL}/books/${this.updatedBook.id}`, {
      name: this.updatedBook.name,
      authors: this.updatedBook.authors,
      section_id: this.updatedBook.section_id,
      content: this.updatedBook.content
    }, {
      headers: {
        "Authorization": `${authToken}`,
      },
    });
    this.closeUpdateBookModal();
    await this.getBooks();
    this.showSuccessMessage('Book updated successfully');
  } catch (error) {
    console.error('Error updating book:', error);
  }
},

    openUpdateSectionModal(section) {
      this.updatedSection = { ...section };
      this.showUpdateSectionModal = true;
    },

    closeUpdateSectionModal() {
      this.showUpdateSectionModal = false;
    },

    async updateSection() {
      try {
        const authToken = localStorage.getItem('authToken');
        await axios.put(`${API_BASE_URL}/section/${this.updatedSection.id}`, this.updatedSection, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.closeUpdateSectionModal();
        await this.getSections();
        this.showSuccessMessage('Section updated successfully');
      } catch (error) {
        console.error('Error updating section:', error);
      }
    },

    showSuccessMessage(message) {
      this.successMessage = message;
      this.showSuccessAlert = true;
      setTimeout(() => {
        this.showSuccessAlert = false;
      }, 3000);
    },
    openUserProfile(userId) {
      // Fetch user data and store it in localStorage
      this.getUserData(userId).then((userData) => {
        localStorage.setItem('profileData', JSON.stringify(userData));
        this.$router.push('/profile_admin');
      });
    },
    async getUserData(userId) {
      try {
        const authToken = localStorage.getItem('authToken');
        const response = await axios.get(`${API_BASE_URL}/get_user/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        return response.data;
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    },
  },
  async mounted() {
    const authToken = localStorage.getItem('authToken');
    if (!authToken) {
      this.$router.push('/login');
      return;
    }

    try {
      await this.getBooks();
      await this.getSections();
      await this.getUsers();
      await this.getIssues();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  },

};
</script>

<style scoped>
.dashboard {
  font-family: Arial, sans-serif;
}

nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px;
}

.left,
.center,
.right {
  flex-basis: 33.33%;
  text-align: center;
}

.right a {
  color: #fff;
  text-decoration: none;
  margin: 0 10px;
}

.content {
  padding: 20px;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.header h2 {
  margin: 0;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}

.modal {
  display: block;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
  background-color: #fefefe;
  margin: 15% auto;
  padding: 20px;
  border: 1px solid #888;
  width: 30%;
}

.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
</style>