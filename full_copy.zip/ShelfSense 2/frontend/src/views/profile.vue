<template>
  <div class="profile">
    <nav>
      <div class="left">
        Hello {{ userName }}
      </div>
      <div class="center">
        ShelfSense
      </div>
      <div class="right">
        <router-link to="/home" style="color: white;">Home</router-link> |
        <router-link @click="triggerSearch" to="#" style="color: white;">Search</router-link> |
        <router-link @click="getUserDetails" to="#" style="color: white;">Profile</router-link> |
        <router-link @click="logout" to="#" style="color: white;">Logout</router-link>
      </div>
    </nav>

    <div class="user-details">
      <p><strong>Username:</strong> {{ userData.username }}</p>
      <p><strong>Email:</strong> {{ userData.email }}</p>
      <p><strong>Last Login:</strong> {{ userData.last_login_at }}</p>
      <p><strong>Current Login:</strong> {{ userData.current_login_at }}</p>
      <p><strong>Login Count:</strong> {{ userData.login_count }}</p>
    </div>

    <div class="current-issues">
      <h2>Current Issues</h2>
      <div v-if="currentIssues.length === 0">
        No current issues.
      </div>
      <table v-else class="current-issues-table">
        <thead>
          <tr>
            <th>Book ID</th>
            <th>Book Name</th>
            <th>Issued Date</th>
            <th></th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="issue in currentIssues" :key="issue.id">
            <td>{{ issue.book_id }}</td>
            <td>{{ getBookName(issue.book_id) }}</td>
            <td>{{ issue.date_issued }}</td>
            <td>
              <button @click="openBook(issue.book_id)">Open</button>
            </td>
            <td>
              <button @click="returnBook(issue.book_id)">Return</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="issue-history">
      <h2>Issue History</h2>
      <div v-if="issueHistory.length === 0">
        No issue history found.
      </div>
      <table v-else class="issue-history-table">
        <thead>
          <tr>
            <th>Book ID</th>
            <th>Book Name</th>
            <th>Issued Date</th>
            <th>Returned Date</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="issue in issueHistory" :key="issue.id">
            <td>{{ issue.book_id }}</td>
            <td>{{ getBookName(issue.book_id) }}</td>
            <td>{{ issue.date_issued }}</td>
            <td>{{ issue.return_date }}</td>
            <td>
              <button @click="openBook(issue.book_id)">Open</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export default {
  data() {
    return {
      userName: localStorage.getItem('userName') || 'User',
      userData: {},
      currentIssues: [],
      issueHistory: [],
      books: [],
    };
  },
  methods: {
    async getUserData() {
      try {
        const authToken = localStorage.getItem('authToken');
        const userId = localStorage.getItem('userId');
        const response = await axios.get(`${API_BASE_URL}/get_user/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.userData = response.data;
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    },
    async getIssues() {
      try {
        const authToken = localStorage.getItem('authToken');
        const userId = localStorage.getItem('userId');
        const response = await axios.get(`${API_BASE_URL}/issued_books/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.currentIssues = response.data.filter(issue => issue.return_date === null);
        this.issueHistory = response.data.filter(issue => issue.return_date !== null);
      } catch (error) {
        console.error('Error fetching issued books:', error);
      }
    },
    async openBook(bookId) {
      this.$router.push(`/book/${bookId}`);
    },
    async returnBook(bookId) {
      try {
        const authToken = localStorage.getItem('authToken');
        const userId = localStorage.getItem('userId');
        const response = await axios.post(`${API_BASE_URL}/return_book`, {
          book_id: bookId,
          user_id: userId,
        }, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        // Handle the response, e.g., show a success message
        console.log(response.data);
        this.getIssues();
      } catch (error) {
        console.error('Error returning book:', error);
      }
    },
    getBookName(bookId) {
      const book = this.books.find(b => b.id === bookId);
      return book ? book.name : 'Unknown';
    },
    triggerSearch() {
      const authToken = localStorage.getItem('authToken');
      const userId = localStorage.getItem('userId');
      const userRole = localStorage.getItem('userRole');
      localStorage.setItem('searchAuth', JSON.stringify({ authToken, userId, userRole }));
      this.$router.push('/search');
    },
    logout() {
      localStorage.clear();
      this.$router.push('/login');
    },
  },
  async mounted() {
    const authToken = localStorage.getItem('authToken');
    if (!authToken) {
      this.$router.push('/login');
      return;
    }

    try {
      // Fetch user data
      await this.getUserData();

      // Fetch issued books
      await this.getIssues();

      // Fetch books
      const booksResponse = await axios.get(`${API_BASE_URL}/books`, {
        headers: {
          "Authorization": `${authToken}`,
        },
      });
      this.books = booksResponse.data;
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  },
};
</script>

<style scoped>

nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px;
}

.user-details {
  margin-bottom: 40px;
}

.current-issues,
.issue-history {
  margin-bottom: 40px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}
</style> 