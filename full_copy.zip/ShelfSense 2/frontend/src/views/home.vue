<template>
  <div class="home">
    <nav>
      <div class="left">
        Hello {{ userName }}
      </div>
      <div class="center">
        ShelfSense
      </div>
      <div class="right">
        <router-link to="/home" style="color: white;">Home</router-link> |
        <router-link @click="triggerSearch" to="#" style="color: white;">Search</router-link> |
        <router-link @click="getUserDetails" to="#" style="color: white;">Profile</router-link> |
        <router-link @click="logout" to="#" style="color: white;">Logout</router-link>
      </div>
    </nav>

    <div class="content">
      <!-- Books section -->
      <div class="books-section">
        <h2>Books</h2>
        <table class="books-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Authors</th>
              <th>Section</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="book in books" :key="book.id">
              <td>{{ book.id }}</td>
              <td>{{ book.name }}</td>
              <td>{{ book.authors }}</td>
              <td>{{ getSectionName(book.section_id) }}</td>
              <td>
                <button @click="openBook(book.id)">Open</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Sections section -->
      <div class="sections-section">
        <h2>Sections</h2>
        <table class="sections-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Description</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="section in sections" :key="section.id">
              <td>{{ section.id }}</td>
              <td>{{ section.name }}</td>
              <td>{{ section.description }}</td>
              <td>
                <button @click="openSection(section.id)">Open</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Issued Books section -->
      <div class="issued-books-section">
        <h2>Issued Books</h2>
        <div v-if="issuedBooks.length === 0">
          No issued books found.
        </div>
        <table v-else class="issued-books-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Issue Date</th>
              <th></th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="issue in issuedBooks" :key="issue.id">
              <td>{{ issue.book_id }}</td>
              <td>{{ getBook(issue.book_id).name }}</td>
              <td>{{ issue.date_issued }}</td>
              <td>
                <button @click="openBook(issue.book_id)">Open</button>
              </td>
              <td>
                <button @click="returnBook(issue.book_id, issue.user_id)">Return</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

export default {
  data() {
    return {
      userName: localStorage.getItem('userName') || 'User',
      userId: localStorage.getItem('userId'),
      books: [],
      sections: [],
      issuedBooks: [],
    };
  },
  methods: {
    async getUserDetails() {
      try {
        const authToken = localStorage.getItem('authToken');
        const userId = localStorage.getItem('userId');
        const response = await axios.get(`${API_BASE_URL}/get_user/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        const userData = response.data;
        localStorage.setItem('userData', JSON.stringify(userData));
        this.$router.push('/profile');
      } catch (error) {
        console.error('Error fetching user details:', error);
      }
    },
    triggerSearch() {
      const authToken = localStorage.getItem('authToken');
      const userId = localStorage.getItem('userId');
      const userRole = localStorage.getItem('userRole');
      localStorage.setItem('searchAuth', JSON.stringify({ authToken, userId, userRole }));
      this.$router.push('/search');
    },
    logout() {
      localStorage.clear();
      this.$router.push('/login');
    },
    async openBook(bookId) {
      this.$router.push(`/book/${bookId}`);
    },
    async openSection(sectionId) {
      this.$router.push(`/section/${sectionId}`);
    },
    async returnBook(bookId, userId) {
  try {
    const authToken = localStorage.getItem('authToken');
    // Send both bookId and userId in the request payload
    const response = await axios.post(`${API_BASE_URL}/return_book`, {
      book_id: bookId,
      user_id: userId,
    }, {
      headers: {
        "Authorization": `${authToken}`,
      },
    });
    // Handle the response, e.g., show a success message
    console.log(response.data);
    // Refresh the issued books data
    await this.getIssues();
  } catch (error) {
    console.error('Error returning book:', error);
  }
},
    async getIssues() {
      try {
        const authToken = localStorage.getItem('authToken');
        const userId = localStorage.getItem('userId');
        const response = await axios.get(`${API_BASE_URL}/issued_books/${userId}`, {
          headers: {
            "Authorization": `${authToken}`,
          },
        });
        this.issuedBooks = response.data.filter(issue => issue.return_date === null);
      } catch (error) {
        console.error('Error fetching issued books:', error);
      }
    },
    getSectionName(sectionId) {
      const section = this.sections.find((section) => section.id === sectionId);
      return section ? section.name : '';
    },
    getBook(bookId) {
      return this.books.find((book) => book.id === bookId);
    },
    getUser(userId) {
      const userData = JSON.parse(localStorage.getItem('userData'));
      const user = userData?.find((user) => user.id === userId);
      return user || { username: 'Unknown' };
    },
  },
  async mounted() {
    const authToken = localStorage.getItem('authToken');
    if (!authToken) {
      this.$router.push('/login');
      return;
    }

    try {
      // Fetch books
      const booksResponse = await axios.get(`${API_BASE_URL}/books`, {
        headers: {
          "Authorization": `${authToken}`,
        },
      });
      this.books = booksResponse.data;

      // Fetch sections
      const sectionsResponse = await axios.get(`${API_BASE_URL}/section`, {
        headers: {
          "Authorization": `${authToken}`,
        },
      });
      this.sections = sectionsResponse.data;

      // Fetch issued books for the current user
      const userId = localStorage.getItem('userId');
      await this.getIssues();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  },
};
</script>

<style scoped>
nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px;
}

.content {
  padding: 20px;
}

.books-section,
.sections-section,
.issued-books-section {
  margin-bottom: 40px;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

button {
  background-color: #4CAF50;
  color: white;
  border: none;
  padding: 6px 12px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 14px;
  cursor: pointer;
  margin-right: 10px;
}
</style>