import { createRouter, createWebHistory } from 'vue-router'
import login from '@/views/login.vue'
import home from '@/views/home.vue'
import register from '@/views/register.vue'
import profile from '@/views/profile.vue'
import search from '@/views/search.vue'
import book from '@/views/book.vue'
import section from '@/views/section.vue'
import dashboard from '@/views/dashboard.vue'
import book_admin from '@/views/book_admin.vue'
import section_admin from '@/views/section_admin.vue'
import profile_admin from '@/views/profile_admin.vue'

const routes = [
  {
    path: '/login',
    name: 'login',
    component: login
  },
  {
    path: '/home',
    name: 'home',
    component: home
  },
  {
    path: '/register',
    name: 'register',
    component: register
  },
  {
    path: '/profile',
    name: 'profile',
    component: profile
  },
  {
    path: '/search',
    name: 'search',
    component: search
  },
  {
    path: '/book/:id',
    name: 'book',
    component: book
  },
  {
    path: '/section/:id',
    name: 'section',
    component: section
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: dashboard
  },
  {
    path: '/book_admin/:id',
    name: 'book_admin',
    component: book_admin
  },
  {
    path: '/section_admin/:id',
    name: 'section_admin',
    component: section_admin
  },
  {
    path: '/profile_admin',
    name: 'profile_admin',
    component: profile_admin
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
